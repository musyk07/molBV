#' Example microbiome data
#'
#' A data frame contains the count table of the 183 genus in the 80 samples.
#'
#' @format A data frame with 183 rows (genus) and 80 columns (samples). All values are non-negative integers.
"exampleMicrobiomeData"
